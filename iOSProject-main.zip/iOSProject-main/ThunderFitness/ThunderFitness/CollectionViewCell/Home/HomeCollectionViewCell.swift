//
//  HomeCollectionViewCell.swift
//  ThunderFitness
//
//  Created by shabnam shaik on 25/11/2021.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {

    
    @IBOutlet var contantView: UIView!
    @IBOutlet var imgView: UIImageView!
    @IBOutlet var titleLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
